<?php

/**
 * @file
 * The PHP page that serves all page requests on a Drupal installation.
 *
 * The routines here dispatch control to the appropriate handler, which then
 * prints the appropriate page.
 *
 * All Drupal code is released under the GNU General Public License.
 * See COPYRIGHT.txt and LICENSE.txt.
 */

/**
 * Root directory of Drupal installation.
 */
define('DRUPAL_ROOT', getcwd());

require_once DRUPAL_ROOT . '/includes/bootstrap.inc';
drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL);

//$order = commerce_order_load('51');
$default_currency = commerce_currency_load('GBP');
/*if($order->status == "checkout_complete"){*/
$order = commerce_cart_order_new($user->uid);
  $line_item = commerce_line_item_load('membership_fee');
  if ($line_item = 'membership_fee'){
      $line_item = commerce_line_item_new('membership_fee', $order->order_id);
      $order_wrapper = entity_metadata_wrapper('commerce_order', $order);
      $line_item_wrapper = entity_metadata_wrapper('commerce_line_item', $line_item);
      // Populate the line item fields
      $line_item_wrapper->quantity = 1;
      $line_item_wrapper->line_item_label = 'Reservation Fee';
      $line_item_wrapper->field_membership_ref = '1';
      $line_item_wrapper->commerce_product = 2;
      // ->data array of items with vat 20% included
      $reservation = node_load(916);
      $hotel = node_load($reservation->field_res_hotel['und'][0]['nid']);
      $line_item_wrapper->commerce_unit_price->amount = 4000;
      $line_item_wrapper->commerce_unit_price->currency_code = $default_currency['code'];
      $line_item_wrapper->field_membership_price->amount = 4000;
      $line_item_wrapper->field_membership_price->currency_code = $default_currency['code'];
      if($hotel->field_hotel_address['und'][0]['country'] == "GB"){
          $tax_rates = commerce_tax_rates();
          if(array_key_exists("uk_tax", $tax_rates)){
              $tax_rate = $tax_rates['uk_tax'];
          }
          commerce_tax_rate_apply($tax_rate, $line_item);
      }
      $line_item_wrapper->field_deposit_ref = $reservation_nid;
      $line_item_wrapper->commerce_display_path = "user/$uid";
      // Save the line item and then the order with the new line item attatched
      commerce_line_item_save($line_item);
      $order_wrapper->commerce_line_items[] = $line_item;
      commerce_order_save($order);
      
      $order = commerce_order_load('74');
      $order_wrapper = entity_metadata_wrapper('commerce_order', $order);
		foreach ($order_wrapper->commerce_line_items as $delta => $line_item_wrapper){
            $line_item = $line_item_wrapper->value();
            dpm($line_item);
            if(array_key_exists("uk_tax", $tax_rates)){
              $tax_rate = $tax_rates['uk_tax'];
          }
          //commerce_tax_rate_apply($tax_rate, $line_item);
          //commerce_line_item_save($line_item);
          $line_item->commerce_unit_price['und'][0]['data']['components'][0]['price']['amount'] = 4000;
		}
		
      commerce_order_save($order);
}




































menu_execute_active_handler();
