<?php 
/**
 * @file
 * Alpha's theme implementation to display a section.
 */
?>
<div<?php print $attributes; ?>>
  <?php print $content; ?>
</div>