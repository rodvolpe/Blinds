<?php if (!empty($content)): ?>
  <aside class="<?php print $classes; ?>">
    <?php print $content; ?>
  </aside>
<?php endif; ?>
