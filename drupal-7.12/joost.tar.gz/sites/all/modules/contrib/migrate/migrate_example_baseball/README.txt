An example migration from comma separated value files into Drupal nodes. Also a
good example of a DynamicMigration (i.e. the same migration class handles
multiple migrations).

We currently depend on Features module just for easy export of a content type.

The data comes from
http://www.retrosheet.org/gamelogs/index.html